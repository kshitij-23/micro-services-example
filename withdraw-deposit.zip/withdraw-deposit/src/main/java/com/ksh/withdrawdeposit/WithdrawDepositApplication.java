package com.ksh.withdrawdeposit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WithdrawDepositApplication {

	public static void main(String[] args) {
		SpringApplication.run(WithdrawDepositApplication.class, args);
	}

}
